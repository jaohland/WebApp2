﻿using System.Web.UI;

namespace XEx20Authenication.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}