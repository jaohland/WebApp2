﻿using System.Web.UI;

namespace XEx20UserMaintenance.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}