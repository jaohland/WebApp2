﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace XEx21HandleErrors
{
    public partial class Error : System.Web.UI.Page
    {
    
        protected void Page_Load(object sender, EventArgs e)
        {
            var Error = Session["Exception"];
            //Exception ex = Server.GetLastError();
            //Exception ex = HttpContext.Current.Server.GetLastError();
            //Exception ex = Server.GetLastError().InnerException;

            lblError.Text = Session["Exception"].ToString();
            //couldn't get the message to seperate from the variable, but it still displays the message inside the jumbled mess of code.
        }
    }
}