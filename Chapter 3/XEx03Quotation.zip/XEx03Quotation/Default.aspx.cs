﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
    }
    protected void btnCalculate_Click1(object sender, EventArgs e)
    {
        if(IsValid)
        {
            int salesPrice = Convert.ToInt32(txtSalesPrice.Text);
            decimal discountPercent = Convert.ToDecimal(txtDiscountPercent.Text)/100;
            decimal discountAmount=(salesPrice*discountPercent);
            decimal totalPrice = (salesPrice - discountAmount);
            lblDiscountAmount.Text = discountAmount.ToString("c");
            lblTotalPrice.Text = totalPrice.ToString("c");
        }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        txtDiscountPercent.Text = "";
        txtSalesPrice.Text = "";
        lblDiscountAmount.Text = "";
        lblTotalPrice.Text = "";
    }
}