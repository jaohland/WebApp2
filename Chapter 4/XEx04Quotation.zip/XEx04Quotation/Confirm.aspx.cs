﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

public partial class Confirm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        if (Session["confirmAmount"] != null && Session["confirmPrice"] != null && Session["confirmTotal"] != null)
        {
            decimal discount = (decimal)Session["confirmAmount"];
            decimal sale = (decimal)Session["confirmPrice"];
            decimal total = (decimal)Session["confirmTotal"];
            lblSalesPrice.Text = sale.ToString("c");
            lblTotalPrice.Text = total.ToString("c");
            lblDiscountAmount.Text = discount.ToString("c");
        }
    }

    protected void btnSendQuotation_Click(object sender, EventArgs e)
    {
        Session.Add("name", txtName);
        Session.Add("email", txtEmail);
        // Didn't get the message customized
        lblMessage.Text = "Quotation sent to ";
        Session["confirmAmount"] = null;
        Session["confirmPrice"] = null;
        Session["confirmTotal"] = null;
    }

    protected void btnReturn_Click(object sender, EventArgs e)
    {

    }
}