﻿using System.Web.UI;

namespace JakeFinal.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}