﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(JakeFinal.Startup))]
namespace JakeFinal
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
